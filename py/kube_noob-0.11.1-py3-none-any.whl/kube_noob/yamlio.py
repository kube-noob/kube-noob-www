"""Safe multi-document YAML loading with source line tracking.

Defences: input size cap, document count cap, alias/anchor expansion budget (billion-laughs), nesting depth cap,
SafeLoader only. Duplicate mapping keys are recorded (PyYAML keeps the last one silently, the API server's strict
decoding rejects them) so the audit can report them instead of judging a different object than kubectl would.
Every parsed document keeps a map ``path tuple -> 1-based line`` so findings can point at exact lines.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

import yaml

from kube_noob.errors import ManifestError
from kube_noob.sanitize import has_invisible, replace_surrogates

MAX_INPUT_BYTES = 5_000_000
MAX_DOCUMENTS = 1000
MAX_NODE_VISITS = 500_000
MAX_DEPTH = 100

PathT = tuple[str | int, ...]


@dataclass
class Document:
    index: int
    data: Any
    lines: dict[PathT, int] = field(default_factory=dict)
    start_line: int = 1
    duplicate_keys: list[tuple[PathT, int]] = field(default_factory=list)
    #: Per-list memo for `locator`: the keys a list's items share, computed once per list rather than once
    #: per finding (G252). Out of `repr` and `==` so a Document still prints and compares as its content.
    ambiguous_keys: dict[PathT, frozenset[str]] = field(default_factory=dict, repr=False, compare=False)
    #: The kind of the list this document was opened out of (`PodList`, `List`), or "" for a document of its own.
    #: A reader that counts what a typed list held (the operators inventory) needs to know which list an item
    #: that was not an object came from (G272).
    from_list: str = field(default="", repr=False, compare=False)
    #: Duplicate keys of a LIST WRAPPER this document was opened out of (`items` twice, `kind` twice), as
    #: `(path, line, wrapper kind, note)`, carried by the first document opened from it so `KN-V018` still fires
    #: with the wrapper's line and names the wrapper that has the key twice. PyYAML keeps the last value silently
    #: and the API server's strict decoder refuses the file, so dropping these records with the wrapper audited a
    #: different object than kubectl would, which is what the record exists to prevent (G272, sixth review). The
    #: note says what became of an occurrence that was not a sequence ("items on line 15 is a mapping, not a
    #: list, and was not read"), or is "".
    wrapper_duplicate_keys: list[tuple[PathT, int, str, str]] = field(default_factory=list, repr=False, compare=False)
    #: The same notes for this document's OWN `items` occurrences, when it was not opened (every sequence
    #: occurrence was empty): `(path, line, note)`.
    refused_keys: list[tuple[PathT, int, str]] = field(default_factory=list, repr=False, compare=False)

    def line_for(self, path: PathT) -> int:
        """Best line for a path: exact match, else nearest existing ancestor, else doc start."""
        p = tuple(path)
        while p:
            if p in self.lines:
                return self.lines[p]
            p = p[:-1]
        return self.start_line

    @property
    def kind(self) -> str:
        """The kind when it is a string, else "": a `kind: 7` or `kind: [Pod]` matches no rule's kind, and never
        reaches a message as a Python repr (`ref` names it with a fixed phrase, G272)."""
        kind = self.data.get("kind") if isinstance(self.data, dict) else None
        return kind if isinstance(kind, str) else ""

    @property
    def api_version(self) -> str:
        """The declared apiVersion, or "" when there is none: a missing key, a null, or a value that is not a string
        (which the audit refuses by shape; `str(None)` here once put "None" into a finding, review 4, R6)."""
        value = self.data.get("apiVersion") if isinstance(self.data, dict) else None
        return value if isinstance(value, str) else ""

    def kind_label(self) -> str:
        """What a message calls this document's kind: the kind, or a fixed phrase for a null, empty or
        non-string one -- never the input's own repr (R6, G272)."""
        if self.kind:
            return self.kind
        if isinstance(self.data, dict) and self.data.get("kind") not in (None, ""):
            return "<kind not a string>"
        return "<no kind>"

    @property
    def name(self) -> str:
        if isinstance(self.data, dict) and isinstance(self.data.get("metadata"), dict):
            return str(self.data["metadata"].get("name", ""))
        return ""

    @property
    def namespace(self) -> str | None:
        if isinstance(self.data, dict) and isinstance(self.data.get("metadata"), dict):
            ns = self.data["metadata"].get("namespace")
            return str(ns) if ns is not None else None
        return None

    def ref(self) -> str:
        ns = f"{self.namespace}/" if self.namespace else ""
        return f"{self.kind_label()}/{ns}{self.name or '<unnamed>'}"


def _walk(
    node: yaml.Node,
    path: PathT,
    out: dict[PathT, int],
    budget: list[int],
    line: int | None = None,
    dups: list[tuple[PathT, int]] | None = None,
) -> None:
    budget[0] -= 1
    if budget[0] < 0:
        raise ManifestError("YAML is too complex to process safely (node budget exceeded; possible alias/anchor bomb).")
    if len(path) > MAX_DEPTH:
        raise ManifestError(f"YAML nesting is too deep: more than {MAX_DEPTH} levels; refusing to process.")
    out.setdefault(path, line if line is not None else node.start_mark.line + 1)
    if isinstance(node, yaml.ScalarNode) and isinstance(node.value, str):
        # A YAML escape like "\ud800" decodes to a lone surrogate, which is not text: every encode to UTF-8
        # (a fingerprint, a SARIF file, the terminal) raised, and one such name failed the whole audit (G279).
        node.value = replace_surrogates(node.value)
    if isinstance(node, yaml.MappingNode):
        seen: set[str] = set()
        for key_node, value_node in node.value:
            if isinstance(key_node, yaml.ScalarNode) and isinstance(key_node.value, str):
                key_node.value = replace_surrogates(key_node.value)
            key = key_node.value if isinstance(key_node, yaml.ScalarNode) else str(key_node.start_mark.line)
            if dups is not None and key != "<<":
                if key in seen:
                    dups.append(((*path, key), key_node.start_mark.line + 1))
                seen.add(key)
            _walk(value_node, (*path, key), out, budget, key_node.start_mark.line + 1, dups)
    elif isinstance(node, yaml.SequenceNode):
        for i, child in enumerate(node.value):
            _walk(child, (*path, i), out, budget, None, dups)


def load_documents(text: str) -> list[Document]:
    """Parse one or more YAML documents. Empty documents are skipped. ``List`` kinds are flattened."""
    if len(text.encode("utf-8", errors="replace")) > MAX_INPUT_BYTES:
        raise ManifestError(f"Input exceeds {MAX_INPUT_BYTES} bytes; split it into smaller files.")
    try:
        # Inside the try, because the Reader validates the whole string here: a control character (ESC, NUL)
        # raises ReaderError from the constructor, and with this line outside the handler that YAMLError escaped
        # as an unhandled exception -- which the MCP server turns into a 500 "internal error" for what is simply
        # input it cannot parse. A caller cannot act on a 500.
        loader = yaml.SafeLoader(text)
    except yaml.YAMLError as exc:
        raise ManifestError(f"Invalid YAML: {exc}") from exc
    docs: list[Document] = []
    budget = [MAX_NODE_VISITS]
    try:
        while loader.check_node():
            node = loader.get_node()
            if node is None:
                continue
            lines: dict[PathT, int] = {}
            dups: list[tuple[PathT, int]] = []
            _walk(node, (), lines, budget, None, dups)
            data = loader.construct_document(node)
            if data is None:
                continue
            if len(docs) >= MAX_DOCUMENTS:
                raise ManifestError(f"More than {MAX_DOCUMENTS} YAML documents; split the input.")
            refused: list[tuple[PathT, int, str]] = []
            _keep_every_items(node, data, lines, dups, refused, loader, budget)
            docs.append(
                Document(
                    index=len(docs),
                    data=data,
                    lines=lines,
                    start_line=node.start_mark.line + 1,
                    duplicate_keys=dups,
                    refused_keys=refused,
                )
            )
    except yaml.YAMLError as exc:
        raise ManifestError(f"Invalid YAML: {exc}") from exc
    except RecursionError as exc:
        raise ManifestError(f"YAML nesting is too deep to process safely (limit {MAX_DEPTH} levels).") from exc
    finally:
        loader.dispose()
    return _flatten_lists(docs)


def _keep_every_items(
    node: yaml.Node,
    data: Any,
    lines: dict[PathT, int],
    dups: list[tuple[PathT, int]],
    refused: list[tuple[PathT, int, str]],
    loader: yaml.SafeLoader,
    budget: list[int],
    prefix: PathT = (),
) -> None:
    """A list wrapper with `items` given twice holds every object under every SEQUENCE occurrence, in place --
    at the top of a document and in every list wrapper nested in one; an occurrence that is not a sequence is
    named in ``refused`` and read by nothing.

    PyYAML keeps the last `items` and drops the rest, so a privileged Pod under the first `items:` vanished from
    a file that `KN-V018` then did not even report (the wrapper's duplicate record went with the wrapper when the
    list was opened), and when the LAST occurrence was a mapping the sixth round's join gave up and the Pod was
    lost again, unnamed. The API server's strict decoder refuses the file; what kube-noob can say truthfully is
    that it is refused (`KN-V018`, with the wrapper's line, naming the occurrence that was not a list) AND what
    every sequence held, so nothing in the file goes unaudited. The line map is rebuilt for the joined list,
    each occurrence walked at its offset (G272).
    """
    if not isinstance(node, yaml.MappingNode) or not is_list_kind(data):
        return
    pairs = [(k, v) for k, v in node.value if isinstance(k, yaml.ScalarNode) and k.value == "items"]
    items_path: PathT = (*prefix, "items")
    sequences = [v for _, v in pairs if isinstance(v, yaml.SequenceNode)]
    if len(pairs) > 1:
        for n, (key_node, value_node) in enumerate(pairs, start=1):
            if not isinstance(value_node, yaml.SequenceNode):
                what = (
                    "a mapping"
                    if isinstance(value_node, yaml.MappingNode)
                    else "a string"
                    if isinstance(value_node, yaml.ScalarNode) and value_node.value
                    else "a null"
                )
                refused.append(
                    (
                        items_path,
                        key_node.start_mark.line + 1,
                        f"items on line {key_node.start_mark.line + 1} (occurrence {n}) is {what}, not a list, and was "
                        "not read",
                    )
                )
        if not sequences:
            return  # nothing to join: the wrapper stays as PyYAML read it, and KN-V018 names every occurrence
        joined: list[Any] = []
        for value_node in sequences:
            value = loader.construct_object(value_node, deep=True)
            joined.extend(value if isinstance(value, list) else [value])
        depth = len(items_path)
        for key in [k for k in lines if len(k) > depth and k[:depth] == items_path]:
            del lines[key]
        dups[:] = [(key, line) for key, line in dups if not (len(key) > depth and key[:depth] == items_path)]
        offset = 0
        for value_node in sequences:
            part: dict[PathT, int] = {}
            part_dups: list[tuple[PathT, int]] = []
            _walk(value_node, items_path, part, budget, None, part_dups)
            for key, line in part.items():
                if len(key) > depth and isinstance(index := key[depth], int):
                    lines.setdefault((*items_path, index + offset, *key[depth + 1 :]), line)
            for key, line in part_dups:
                if len(key) > depth and isinstance(index := key[depth], int):
                    dups.append(((*items_path, index + offset, *key[depth + 1 :]), line))
            offset += len(value_node.value)
        data["items"] = joined
    items = data["items"]
    if not isinstance(items, list):
        return
    children = [child for value_node in sequences for child in value_node.value]
    for i, child in enumerate(children[: len(items)]):
        if isinstance(child, yaml.MappingNode) and isinstance(items[i], dict):
            _keep_every_items(child, items[i], lines, dups, refused, loader, budget, (*items_path, i))


def is_list_kind(data: object) -> bool:
    """`List`, or a typed list (`PodList`, `DeploymentList`) as `kubectl get -o yaml` and must-gathers write it:
    a kind ending in `List` with `items` and no `spec`. Only `List` was unwrapped before G272, so the pods in a
    PodList were never audited."""
    if not isinstance(data, dict):
        return False
    kind = data.get("kind")
    return isinstance(kind, str) and kind.endswith("List") and "items" in data and "spec" not in data


def is_empty_list(data: object) -> bool:
    """A list wrapper that held nothing: the one list shape `load_documents` leaves in its output. It is the
    record that the kind was read and held no items, not an object, so no object rule applies to it and it is not
    a resource. `items: null` (or a bare `items:`) is the same list as `items: []`: the API's decoder reads a null
    slice as empty (G272, seventh review)."""
    return is_list_kind(data) and isinstance(data, dict) and (data["items"] is None or data["items"] == [])


def _open_list(d: Document, first_index: int) -> list[Document]:
    """One document per item of a list document, each with its own slice of the line map.

    One pass over the line map: the keys are grouped by the item index they start with, so a 9,000-item list is
    9,000 dictionaries and not 9,000 scans of the whole map (G272's fifth review found the per-item rescan
    took minutes). An item that is not a mapping -- a trailing null, a string, a number -- is its own document
    too: `KN-V001` reports it, and dropping it, or leaving the list unopened because of it, hid every other item
    from every rule. An item of a typed list with no `kind` or `apiVersion`, or with a null or empty one (the
    zero value the API's decoder reads them as), takes the list's, set in place so the fixer still writes to
    the same dict; an item of ANOTHER kind (`kind: Deployment` in a `PodList`) inherits nothing, because the
    list's group does not apply to it (G272, seventh review). The wrapper's OWN duplicate keys and refused
    occurrences go to the first opened document, with the wrapper's kind, so `KN-V018` still fires with the
    wrapper's line (G272, sixth and seventh reviews).
    """
    if not isinstance(d.data, dict):
        return [d]
    items = d.data["items"]
    kind = str(d.data.get("kind"))
    element = kind[: -len("List")] if kind != "List" else ""
    api_version = d.data.get("apiVersion")
    by_item: dict[int, dict[PathT, int]] = {}
    for key, line in d.lines.items():
        if len(key) >= 2 and key[0] == "items" and isinstance(key[1], int):
            by_item.setdefault(key[1], {})[key[2:]] = line
    dups_by_item: dict[int, list[tuple[PathT, int]]] = {}
    wrapper_dups = list(d.wrapper_duplicate_keys)
    for key, line in d.duplicate_keys:
        if len(key) >= 2 and key[0] == "items" and isinstance(key[1], int):
            dups_by_item.setdefault(key[1], []).append((key[2:], line))
        else:
            wrapper_dups.append((key, line, kind, ""))
    refused_by_item: dict[int, list[tuple[PathT, int, str]]] = {}
    for key, line, note in d.refused_keys:
        if len(key) >= 2 and key[0] == "items" and isinstance(key[1], int):
            refused_by_item.setdefault(key[1], []).append((key[2:], line, note))
        else:
            # Folded into the wrapper's own duplicate record for that key (one KN-V018 per key, naming every
            # occurrence that was not a list), which always exists where a note does.
            wrapper_dups = [
                (k, ln, kd, f"{nt}; {note}" if nt else note) if (k == key and kd == kind) else (k, ln, kd, nt)
                for k, ln, kd, nt in wrapper_dups
            ]
    out: list[Document] = []
    for i, item in enumerate(items):
        if element and isinstance(item, dict):
            own = item.get("kind")
            if own in (None, ""):
                item["kind"] = element
            if item.get("kind") == element and isinstance(api_version, str) and item.get("apiVersion") in (None, ""):
                item["apiVersion"] = api_version
        out.append(
            Document(
                index=first_index + len(out),
                data=item,
                lines=by_item.get(i, {}),
                start_line=d.line_for(("items", i)),
                duplicate_keys=dups_by_item.get(i, []),
                refused_keys=refused_by_item.get(i, []),
                from_list=kind,
                wrapper_duplicate_keys=wrapper_dups if not out else [],
            )
        )
    return out


def _flatten_lists(docs: list[Document]) -> list[Document]:
    """Open every list kind whose `items` is a list, nested lists included, into one document per item.

    A list whose `items` is not a list stays as it is, and the control-plane rules decline it; an EMPTY list of
    either spelling (`kubectl get pods -o yaml` with no pods, a `kind: List` with no items, `items: null`) stays
    too, as the record that the kind was read and held nothing, which an opened-into-nothing list could not say
    -- the audit refuses a bundle that is only such records with one message for both spellings, `KN-V001` does
    not treat the wrapper as an object, and it is not a resource (G272, sixth and seventh reviews). The document
    cap is applied to what comes OUT, so a 1,500-item `PodList` is refused exactly as 1,500 documents are, by
    every command alike (G272): before this the audit opened it, produced 17 MB of JSON, and `fix` refused the
    same file with exit 4.
    """
    out: list[Document] = []
    queue = list(docs)
    while queue:
        d = queue.pop(0)
        if (
            is_list_kind(d.data)
            and isinstance(d.data, dict)
            and isinstance(d.data.get("items"), list)
            and d.data["items"]
        ):
            opened = _open_list(d, len(out))
            if len(out) + len(opened) > MAX_DOCUMENTS:
                raise ManifestError(f"More than {MAX_DOCUMENTS} YAML documents; split the input.")
            # Nested lists open in place, ahead of what follows; a list item of a list goes back to the front.
            queue[0:0] = opened
            continue
        d.index = len(out)
        out.append(d)
        if len(out) > MAX_DOCUMENTS:
            raise ManifestError(f"More than {MAX_DOCUMENTS} YAML documents; split the input.")
    return out


#: A ``::`` that a line of the dumped string could start with: at its start; after white space (a block
#: scalar's line, or where the emitter folds a plain or single-quoted scalar); or after any character the
#: emitter may ESCAPE in a double-quoted scalar (``"``, ``\``, a control, anything outside printable ASCII),
#: because PyYAML also folds right after an escape -- the end-to-end fuzz found ``::set-output`` starting a
#: continuation line that way. ``[::]:80``, ``fe80::1`` and ``std::io`` cannot start a line and keep their
#: style (G279, third review).
_LINE_COLONS = re.compile(r'(?:^|[^\x21-\x7e]|["\\])::')
_SERVICE = re.compile(r"(##[A-Za-z]*)\[")


def _command_like(text: str) -> bool:
    """Whether a string could put a CI workflow command in a log: a ``##[``, ``##vso[`` or ``##teamcity[``
    anywhere, or a ``::`` a line could start with -- see ``sanitize.CommandGuard``."""
    if "::" in text and _LINE_COLONS.search(text):
        return True
    return "##" in text and _SERVICE.search(text) is not None


def json_document(obj: Any, **kwargs: Any) -> str:
    """``json.dumps``, with the bracket of ``##[``, ``##vso[`` and ``##teamcity[`` written ``\\u005b``: the same
    JSON, and no line a CI runner reads as a service message (G279). ``#`` occurs only inside JSON strings, so the
    replacement never touches the syntax, and a pretty-printed line never starts with ``::``."""
    text = json.dumps(obj, **kwargs)
    return _SERVICE.sub(r"\1\\u005b", text) if "##" in text else text


class TerminalSafeDumper(yaml.SafeDumper):
    """``yaml.SafeDumper`` whose output is safe on a terminal AND loses nothing (G279).

    A string holding a character ``sanitize.visible`` would change -- an escape sequence, a control, a bidi
    override, a format character -- is written double-quoted with every non-ASCII character escaped, so the bytes
    carry no such character and load back to exactly the same string. A string that could put a GitHub workflow
    command in a log (``##[``, ``::``) is written double-quoted on one line, ``[`` after ``##`` as ``\\x5B``. Every
    other string is written as before, Unicode included, so output without those characters is byte-identical."""

    def analyze_scalar(self, scalar: str) -> Any:
        analysis = super().analyze_scalar(scalar)
        if has_invisible(scalar, keep="\n\t") or _command_like(scalar):
            analysis.allow_flow_plain = analysis.allow_block_plain = False
            analysis.allow_single_quoted = analysis.allow_block = False
        return analysis

    def write_double_quoted(self, text: str, split: bool = True) -> None:
        if _command_like(text):
            self._write_one_line_double_quoted(text)
            return
        if not has_invisible(text, keep="\n\t"):
            super().write_double_quoted(text, split)
            return
        saved, self.allow_unicode = self.allow_unicode, False
        try:
            super().write_double_quoted(text, split)
        finally:
            self.allow_unicode = saved

    def _write_one_line_double_quoted(self, text: str) -> None:
        """A double-quoted scalar on ONE line (never folded, so no line starts with ``::``), printable ASCII only,
        ``[`` after ``##`` escaped. Loads back to exactly ``text``."""
        out = []
        for ch in text:
            o = ord(ch)
            if ch in '"\\':
                out.append("\\" + ch)
            elif 0x20 <= o < 0x7F:
                out.append(ch)
            elif o <= 0xFF:
                out.append(f"\\x{o:02X}")
            elif o <= 0xFFFF:
                out.append(f"\\u{o:04X}")
            else:
                out.append(f"\\U{o:08X}")
        data = _SERVICE.sub(r"\1\\x5B", "".join(out))
        self.write_indicator('"', True)
        self.column += len(data)
        self.stream.write(data.encode(self.encoding) if self.encoding else data)
        self.write_indicator('"', False)


def dump_yaml(obj: Any, **kwargs: Any) -> str:
    """``yaml.safe_dump`` through :class:`TerminalSafeDumper`: the YAML kube-noob prints and writes."""
    return str(yaml.dump(obj, Dumper=TerminalSafeDumper, **kwargs))


class _Dumper(TerminalSafeDumper):
    pass


def _str_presenter(dumper: yaml.SafeDumper, data: str) -> yaml.ScalarNode:
    if "\n" in data:
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


_Dumper.add_representer(str, _str_presenter)


def dump_documents(objs: list[Any]) -> str:
    """Deterministic YAML: insertion order preserved, block style, ``---`` separated."""
    parts = [
        yaml.dump(o, Dumper=_Dumper, sort_keys=False, default_flow_style=False, width=120, allow_unicode=True)
        for o in objs
    ]
    return "---\n" + "---\n".join(parts)


def get_path(data: Any, path: PathT) -> Any:
    cur = data
    for p in path:
        if isinstance(p, int):
            if not isinstance(cur, list) or p >= len(cur):
                return None
            cur = cur[p]
        else:
            if not isinstance(cur, dict):
                return None
            cur = cur.get(p)
    return cur


def fmt_path(path: PathT) -> str:
    s = ""
    for p in path:
        s += f"[{p}]" if isinstance(p, int) else (f".{p}" if s else str(p))
    return s


def locator(data: Any, path: PathT, ambiguous: dict[PathT, frozenset[str]] | None = None) -> str:
    """``fmt_path`` with list indices replaced by the key that identifies the item.

    ``spec.template.spec.containers[0].securityContext`` becomes
    ``spec.template.spec.containers[name=api].securityContext``.

    An index is a position, and positions move: inserting a sidecar at the front renames every finding
    on every other container, so anything keyed on the raw path reports N fixed and N new findings for
    a change that fixed nothing. The container's name is the thing that did not move, and it lives only
    in the finding's message, which is the one field an identity must not use because messages carry
    counts and sorted lists that change on their own.

    Items with no natural key keep the index, and that is honest: a NetworkPolicy's ``ingress[1]`` and
    an RBAC ``rules[0]`` are identified by position in the API itself, so there is nothing better to use.

    A name two siblings SHARE is not a key either, so those items keep the index as well. The API server
    refuses most duplicates, but a rule that reports the duplicate is reading the object that still has it:
    two different defects on two entries called `gpu` would otherwise hash to one identity, and a baseline
    entry for either would suppress the other. Only the ambiguous entries fall back -- a unique sibling in
    the same list keeps its name.
    """
    out = ""
    for i, seg in enumerate(path):
        if not isinstance(seg, int):
            out += f".{seg}" if out else str(seg)
            continue
        key = _item_key(get_path(data, tuple(path[: i + 1])))
        if key and key in _ambiguous_keys(data, tuple(path[:i]), ambiguous):
            key = ""
        out += f"[{key or seg}]"
    return out


def _ambiguous_keys(data: Any, prefix: PathT, cache: dict[PathT, frozenset[str]] | None) -> frozenset[str]:
    """The keys two or more items of the list at ``prefix`` share, computed once per list when a cache is given.

    Without the cache this scanned every sibling for every finding, which is O(n^2) in the list's length: a
    Deployment with 2,000 containers took six seconds and one with 16,000 took six minutes, so an object
    padded with containers outran the admission webhook's three-second timeout and was admitted with no
    warning and no denial -- while the single process stayed busy and every other request timed out with it.
    One pass per list makes it linear (G252).
    """
    if cache is not None and prefix in cache:
        return cache[prefix]
    siblings = get_path(data, prefix)
    seen: dict[str, int] = {}
    if isinstance(siblings, list):
        for item in siblings:
            key = _item_key(item)
            if key:
                seen[key] = seen.get(key, 0) + 1
    out = frozenset(k for k, n in seen.items() if n > 1)
    if cache is not None:
        cache[prefix] = out
    return out


def _item_key(item: Any) -> str:
    """The field that identifies a list item, or ``""`` when nothing in it does."""
    if isinstance(item, dict):
        for field_name in ("name", "containerName"):
            value = item.get(field_name)
            if isinstance(value, str) and value:
                return f"{field_name}={value}"
        meta = item.get("metadata")
        if isinstance(meta, dict) and isinstance(meta.get("name"), str) and meta["name"]:
            return f"metadata.name={meta['name']}"
    elif isinstance(item, str) and item:
        return item  # a scalar list entry identifies itself: capabilities.add[ALL]
    return ""
