"""Local knowledge base: built-in curated docs + ingested corpus, searched with BM25.

Every chunk carries provenance (source URL, license, version, retrieval time) so answers can credit their sources
("source attribution credits"). Chunk ids are stable: ``kn:<doc-id>#<n>``.
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import threading
from collections import Counter, OrderedDict
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any

import yaml

_TOKEN = re.compile(r"[a-z0-9][a-z0-9._/-]*[a-z0-9]|[a-z0-9]")
_STOP = frozenset(
    [
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "by",
        "for",
        "from",
        "has",
        "have",
        "how",
        "i",
        "in",
        "is",
        "it",
        "its",
        "of",
        "on",
        "or",
        "that",
        "the",
        "this",
        "to",
        "was",
        "what",
        "when",
        "where",
        "which",
        "who",
        "why",
        "will",
        "with",
        "you",
        "your",
        "can",
        "do",
        "does",
        "not",
        "no",
    ]
)
MAX_CHUNK_CHARS = 1600
_log = logging.getLogger(__name__)
CITATION_RE = re.compile(r"\[(kn:[A-Za-z0-9._/-]+#\d+)\]")


# Two-word spellings of one Kubernetes term, and common abbreviations, map to one token so "service account",
# "ServiceAccount" and "sa" all meet in the index.
_JOINS = {
    ("service", "account"): "serviceaccount",
    ("config", "map"): "configmap",
    ("egress", "ip"): "egressip",
    ("network", "policy"): "networkpolicy",
    ("cluster", "role"): "clusterrole",
    ("role", "binding"): "rolebinding",
    ("persistent", "volume"): "persistentvolume",
    ("stateful", "set"): "statefulset",
    ("daemon", "set"): "daemonset",
    ("deployment", "config"): "deploymentconfig",
    ("ingress", "class"): "ingressclass",
    ("storage", "class"): "storageclass",
    ("machine", "pool"): "machinepool",
    ("name", "space"): "namespace",
}
_ABBREVIATIONS = {
    "sa": "serviceaccount",
    "pvc": "persistentvolumeclaim",
    "pv": "persistentvolume",
    "pdb": "poddisruptionbudget",
    "hpa": "horizontalpodautoscaler",
    "scc": "securitycontextconstraints",
    "dc": "deploymentconfig",
    "rwx": "readwritemany",
    "rwo": "readwriteonce",
    "cm": "configmap",
    "ns": "namespace",
    "hcp": "hostedcontrolplane",
}


def _singular(tok: str) -> str | None:
    if len(tok) > 3 and tok.isalpha() and tok.endswith("s") and not tok.endswith(("ss", "us", "is")):
        return tok[:-1]
    return None


def tokenize(text: str) -> list[str]:
    out: list[str] = []
    prev: str | None = None
    for tok in _TOKEN.findall(text.lower()):
        if prev is not None:
            joined = _JOINS.get((prev, _singular(tok) or tok))
            if joined:
                out.append(joined)
        prev = tok
        if tok in _STOP:
            continue
        out.append(tok)
        if tok in _ABBREVIATIONS:
            out.append(_ABBREVIATIONS[tok])
        single = _singular(tok)
        if single:
            out.append(single)
        if any(ch in tok for ch in "-./"):
            out.extend(p for p in re.split(r"[-./]", tok) if p and p not in _STOP)
        if "/" in tok:
            # A prefixed name ("service.beta.openshift.io/serving-cert-secret-name") is often written bare.
            name = tok.rsplit("/", 1)[1]
            if "-" in name and name not in _STOP:
                out.append(name)
    return out


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    title: str
    heading: str
    text: str
    url: str | None
    license: str
    origin: str  # builtin | corpus | local (the user's confirmed learning notes; never exported)
    source_id: str
    version: str | None = None
    redistributable: bool = True
    extra: dict[str, Any] = field(default_factory=dict)

    def citation(self) -> dict[str, Any]:
        return {
            "chunkId": self.chunk_id,
            "title": self.title + (f" > {self.heading}" if self.heading and self.heading != self.title else ""),
            "url": self.url,
            "license": self.license,
            "sourceId": self.source_id,
            "version": self.version,
            "origin": self.origin,
        }


def _split_markdown(body: str) -> Iterator[tuple[str, str]]:
    """Sections by heading. A ``#`` line inside a fenced code block is a shell or YAML comment, not a heading."""
    heading = ""
    buf: list[str] = []
    fence = ""
    for line in body.splitlines():
        marker = re.match(r"^\s{0,3}(`{3,}|~{3,})", line)
        if marker and (not fence or marker.group(1).startswith(fence)):
            fence = "" if fence else marker.group(1)
        m = None if fence or marker else re.match(r"^(#{1,3})\s+(.*)$", line)
        if m:
            if "".join(buf).strip():
                yield heading, "\n".join(buf).strip()
            heading, buf = m.group(2).strip(), []
        else:
            buf.append(line)
    if "".join(buf).strip():
        yield heading, "\n".join(buf).strip()


_ITEM_START = re.compile(r"^(\s{0,1}[-*+] |\s{0,1}\d+\. |\||#)")
MIN_TAIL_CHARS = 240


def _sentence_cut(text: str, limit: int) -> int:
    """Index to cut ``text`` at: the last sentence end before ``limit``, else ``limit``."""
    window = text[:limit]
    best = max(window.rfind(". "), window.rfind(".\n"), window.rfind("; "))
    return best + 1 if best > limit // 2 else limit


def _units(paragraph: str) -> list[str]:
    """Break an over-long paragraph at list items and table rows (continuation lines stay with their item), and only
    then at sentence ends, so a fact is never split mid-sentence when it can be avoided."""
    if len(paragraph) <= MAX_CHUNK_CHARS:
        return [paragraph]
    items: list[str] = []
    for line in paragraph.splitlines():
        if items and not _ITEM_START.match(line):
            items[-1] += "\n" + line
        else:
            items.append(line)
    out: list[str] = []
    for item in items:
        rest = item
        while len(rest) > MAX_CHUNK_CHARS:
            cut = _sentence_cut(rest, MAX_CHUNK_CHARS)
            out.append(rest[:cut].rstrip())
            rest = rest[cut:].lstrip()
        if rest.strip():
            out.append(rest)
    return out


def _size_split(text: str) -> Iterator[str]:
    if len(text) <= MAX_CHUNK_CHARS:
        yield text
        return
    units = [u for p in re.split(r"\n\s*\n", text) for u in _units(p)]
    chunks: list[str] = []
    cur = ""
    for u in units:
        sep = "\n" if cur and _ITEM_START.match(u) and _ITEM_START.match(cur.rsplit("\n", 1)[-1]) else "\n\n"
        if cur and len(cur) + len(sep) + len(u) > MAX_CHUNK_CHARS:
            chunks.append(cur.strip())
            cur = ""
        cur = f"{cur}{sep}{u}" if cur else u
    if cur.strip():
        chunks.append(cur.strip())
    # A short tail reads better with the text before it than as a fragment of its own.
    if len(chunks) > 1 and len(chunks[-1]) < MIN_TAIL_CHARS:
        tail = chunks.pop()
        chunks[-1] = f"{chunks[-1]}\n{tail}"
    yield from chunks


def parse_front_matter(raw: str) -> tuple[dict[str, Any], str]:
    if raw.startswith("---\n"):
        end = raw.find("\n---", 4)
        if end != -1:
            meta = yaml.safe_load(raw[4:end]) or {}
            return (meta if isinstance(meta, dict) else {}), raw[end + 4 :].lstrip("\n")
    return {}, raw


def chunk_document(
    doc_id: str,
    title: str,
    body: str,
    *,
    url: str | None,
    license_: str,
    origin: str,
    source_id: str,
    version: str | None = None,
    redistributable: bool = True,
    extra: dict[str, Any] | None = None,
) -> list[Chunk]:
    chunks: list[Chunk] = []
    n = 0
    for heading, section in _split_markdown(body):
        for piece in _size_split(section):
            chunks.append(
                Chunk(
                    f"kn:{doc_id}#{n}",
                    doc_id,
                    title,
                    heading or title,
                    piece,
                    url,
                    license_,
                    origin,
                    source_id,
                    version,
                    redistributable,
                    dict(extra or {}),
                )
            )
            n += 1
    return chunks


@dataclass
class Hit:
    chunk: Chunk
    score: float

    def as_dict(self, max_chars: int = 700) -> dict[str, Any]:
        text = self.chunk.text
        return {
            **self.chunk.citation(),
            "score": round(self.score, 3),
            "text": text if len(text) <= max_chars else text[:max_chars].rsplit(" ", 1)[0] + " ...",
        }


class KnowledgeStore:
    """BM25 (k1=1.5, b=0.75) over chunks. Thread-safe lazy build."""

    def __init__(self, chunks: Iterable[Chunk]) -> None:
        self.chunks: list[Chunk] = list(chunks)
        self.by_id: dict[str, Chunk] = {c.chunk_id: c for c in self.chunks}
        self._tf: list[Counter[str]] = []
        self._len: list[int] = []
        self._df: Counter[str] = Counter()
        self._postings: dict[str, list[int]] = {}  # term -> chunks that contain it, in chunk order
        for i, c in enumerate(self.chunks):
            toks = tokenize(f"{c.title} {c.heading} {c.heading} {c.text}")
            tf = Counter(toks)
            self._tf.append(tf)
            self._len.append(len(toks))
            self._df.update(tf.keys())
            for t in tf:
                self._postings.setdefault(t, []).append(i)
        self._avg = (sum(self._len) / len(self._len)) if self._len else 0.0

    def search(
        self,
        query: str,
        limit: int = 5,
        origin: str | None = None,
        source_prefix: str | None = None,
        include_restricted: bool = True,
    ) -> list[Hit]:
        q = tokenize(query)
        if not q or not self.chunks:
            return []
        n = len(self.chunks)
        # BM25 with the query's term counts: a word the query repeats counts that many times. Scoring walks each
        # distinct term's postings, so a long or repetitive query costs its distinct words, not its length.
        sums: dict[int, float] = {}
        allowed: dict[int, bool] = {}
        for t, qtf in Counter(q).items():
            df = self._df.get(t)
            if not df:
                continue
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            for i in self._postings[t]:
                ok = allowed.get(i)
                if ok is None:
                    c = self.chunks[i]
                    ok = not (
                        (origin and c.origin != origin)
                        or (source_prefix and not c.source_id.startswith(source_prefix))
                        or (not include_restricted and not c.redistributable)
                    )
                    allowed[i] = ok
                if not ok:
                    continue
                f = self._tf[i][t]
                part = idf * (f * 2.5) / (f + 1.5 * (1 - 0.75 + 0.75 * self._len[i] / (self._avg or 1)))
                sums[i] = sums.get(i, 0.0) + qtf * part
        scores = [(s * self.chunks[i].extra.get("searchWeight", 1.0), i) for i, s in sums.items() if s > 0]
        scores.sort(reverse=True)
        return [Hit(self.chunks[i], s) for s, i in scores[:limit]]

    def doc_frequency(self, token: str) -> float:
        """Share of chunks containing ``token`` (0..1); rare tokens carry the meaning of a claim."""
        return self._df.get(token, 0) / len(self.chunks) if self.chunks else 0.0

    def doc_count(self, token: str) -> int:
        """Number of chunks containing ``token``: unlike the share, adding chunks never lowers it."""
        return self._df.get(token, 0)

    def get(self, chunk_id: str) -> Chunk | None:
        return self.by_id.get(chunk_id)

    def doc(self, doc_id: str) -> list[Chunk]:
        return [c for c in self.chunks if c.doc_id == doc_id]

    def stats(self) -> dict[str, Any]:
        by_origin = Counter(c.origin for c in self.chunks)
        by_source = Counter(c.source_id.split(":")[0] for c in self.chunks)
        return {
            "chunks": len(self.chunks),
            "documents": len({c.doc_id for c in self.chunks}),
            "byOrigin": dict(by_origin),
            "bySource": dict(by_source.most_common(20)),
        }


def requires_groups(value: Any) -> list[list[str]]:
    """A knowledge doc's ``requires`` front matter: groups of words, each group any-of, all groups needed, before the
    doc is offered as the answer to a pasted question. For a doc whose words are broader than its subject: a
    Compose-to-Kubernetes page shares "docker" and "compose" with every Docker Compose question. Malformed values
    raise, so a typo cannot silently drop the gate."""
    if value is None:
        return []
    if not isinstance(value, list) or not all(
        isinstance(g, list) and g and all(isinstance(w, str) and w.strip() for w in g) for g in value
    ):
        raise ValueError(f"requires must be a list of non-empty word lists, got {value!r}")
    return [[w.strip().lower() for w in g] for g in value]


def works_with(value: Any) -> list[str]:
    """A knowledge doc's ``worksWith`` front matter: named products (as the named-product gate in ``insight`` spells
    them) that the doc applies to without naming them in its text, such as the CI systems a roxctl pipeline step runs
    in. Malformed values raise."""
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(w, str) and w.strip() for w in value):
        raise ValueError(f"worksWith must be a list of product names, got {value!r}")
    return [w.strip().lower() for w in value]


def builtin_chunks() -> list[Chunk]:
    out: list[Chunk] = []
    root = resources.files("kube_noob").joinpath("data", "knowledge")
    if not root.is_dir():
        return out
    for f in sorted(root.iterdir(), key=lambda p: p.name):
        if not f.name.endswith(".md"):
            continue
        meta, body = parse_front_matter(f.read_text(encoding="utf-8"))
        doc_id = str(meta.get("id") or f.name[:-3])
        srcs = meta.get("sources") or []
        url = srcs[0].get("url") if srcs and isinstance(srcs[0], dict) else None
        out.extend(
            chunk_document(
                doc_id,
                str(meta.get("title") or doc_id),
                body,
                url=url,
                license_=str(meta.get("license", "Apache-2.0")),
                origin="builtin",
                source_id=f"builtin:{doc_id}",
                version=str(meta.get("updated")) if meta.get("updated") else None,
                extra={
                    "sources": srcs,
                    "tags": meta.get("tags") or [],
                    "platforms": meta.get("platforms") or [],
                    "searchWeight": float(meta.get("searchWeight", 1.0)),
                    "requires": requires_groups(meta.get("requires")),
                    "worksWith": works_with(meta.get("worksWith")),
                },
            )
        )
    return out


def _ticket_shard(f: Path) -> bool:
    """Jira ticket shards (sourceId ``jira:<PROJECT>``) have their own full-text index in ``kube_noob.tickets``: a full
    copy runs to 100k+ tickets, too many for this in-memory index. One shard holds one project, so the first record
    decides."""
    if not f.name.startswith("jira-"):
        return False
    try:
        with f.open(encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    rec = json.loads(line)
                    return isinstance(rec, dict) and str(rec.get("sourceId", "")).startswith("jira:")
    except (OSError, ValueError):
        return False
    return False


def corpus_chunks(data_dir: Path) -> list[Chunk]:
    out: list[Chunk] = []
    cdir = data_dir / "corpus"
    if not cdir.is_dir():
        return out
    listed: set[str] | None = None  # a shard the manifest does not list (a refused import, a stray file) is not read
    manifest = cdir / "MANIFEST.json"
    if manifest.is_file():
        try:
            shards = json.loads(manifest.read_text(encoding="utf-8")).get("shards") or {}
            listed = {str(e.get("file")) for e in shards.values() if isinstance(e, dict)}
        except (ValueError, AttributeError):
            listed = None
    for f in sorted(cdir.glob("*.jsonl")):
        if _ticket_shard(f):
            continue
        if listed is not None and f.name not in listed:
            _log.warning("skipping %s: not listed in the corpus MANIFEST.json", f.name)
            continue
        with f.open(encoding="utf-8") as fh:
            for lineno, line in enumerate(fh, 1):
                if not line.strip():
                    continue
                try:
                    rec = json.loads(line)
                except (json.JSONDecodeError, RecursionError):
                    _log.warning("skipping malformed JSON in %s line %d", f.name, lineno)
                    continue
                if not isinstance(rec, dict) or not isinstance(rec.get("id"), str) or not rec["id"]:
                    _log.warning("skipping corpus record without an id in %s line %d", f.name, lineno)
                    continue
                if str(rec.get("sourceId", "")).startswith("jira:"):
                    continue  # a mixed shard; ticket shards are skipped whole above
                out.extend(
                    chunk_document(
                        rec["id"],
                        rec.get("title") or rec["id"],
                        rec.get("text", ""),
                        url=rec.get("url"),
                        license_=rec.get("license", "unknown"),
                        origin="corpus",
                        source_id=rec.get("sourceId", f.stem),
                        version=rec.get("version"),
                        redistributable=bool(rec.get("redistributable", False)),
                        extra={
                            k: rec[k]
                            for k in (
                                "retrievedAt",
                                "sha256",
                                "labels",
                                "status",
                                "fixVersions",
                                "affectsVersions",
                                "updated",
                                "issueType",
                                "priority",
                            )
                            if k in rec
                        },
                    )
                )
    return out


def local_chunks(data_dir: Path) -> list[Chunk]:
    """The user's confirmed notes from ``learning.json``: searchable and citable, never redistributable."""
    from kube_noob.learn.memory import LearningStore

    out: list[Chunk] = []
    try:
        docs = LearningStore(data_dir).note_documents()
    except Exception as exc:  # noqa: BLE001 - a damaged learning file must never break search
        _log.warning("local learning notes not indexed: %s", exc)
        return out
    for doc in docs:
        for c in chunk_document(
            doc["id"],
            doc["title"],
            doc["body"],
            url=None,
            license_="user-provided (local only)",
            origin="local",
            source_id="local",
            redistributable=False,
            extra={"created": doc.get("created")},
        ):
            out.append(c)
    return out


_lock = threading.Lock()
_stores: OrderedDict[str, KnowledgeStore] = OrderedDict()
_MAX_STORES = 4


def _store_key(data_dir: Path | None) -> str:
    if data_dir is None:
        return "builtin"
    cdir = data_dir / "corpus"
    h = hashlib.sha256(str(data_dir.resolve()).encode())
    if cdir.is_dir():
        for f in sorted(cdir.glob("*.jsonl")):
            if _ticket_shard(f):
                continue
            st = f.stat()
            h.update(f"{f.name}:{st.st_size}:{st.st_mtime_ns}".encode())
    # learning.json feeds the index through local_chunks (the team's confirmed notes), so a new note has to
    # invalidate the cache. Its size and mtime will not do: almost every tool call rewrites the file to bump a
    # counter or record a confirmation, none of which changes a single indexed chunk, and keying on the file meant
    # rebuilding the whole index on nearly every request. Key on the notes themselves.
    learning = data_dir / "learning.json"
    if learning.is_file():
        h.update(b"learning:")
        h.update(_notes_fingerprint(learning))
    return h.hexdigest()


def _notes_fingerprint(learning: Path) -> bytes:
    """The part of ``learning.json`` that reaches the index, hashed. A damaged file falls back to its size and
    mtime, which is the old behaviour: rebuilding too often is safe, serving a stale index is not."""
    try:
        data = json.loads(learning.read_text(encoding="utf-8"))
        notes = data["notes"] if isinstance(data, dict) else None
        if not isinstance(notes, list):
            raise ValueError("no notes list")
        return hashlib.sha256(json.dumps(notes, sort_keys=True, default=str).encode()).digest()
    except (OSError, ValueError, KeyError, TypeError, RecursionError):
        st = learning.stat()
        return f"{st.st_size}:{st.st_mtime_ns}".encode()


def get_store(data_dir: Path | None = None) -> KnowledgeStore:
    """Store for the built-in docs plus the corpus under ``data_dir``; cached per corpus state (small LRU) so callers
    using different data dirs never evict each other on every call. Rebuilt when corpus files change."""
    key = _store_key(data_dir)
    with _lock:
        store = _stores.get(key)
        if store is None:
            chunks = builtin_chunks()
            if data_dir is not None:
                chunks.extend(corpus_chunks(data_dir))
                chunks.extend(local_chunks(data_dir))
            store = KnowledgeStore(chunks)
            _stores[key] = store
            while len(_stores) > _MAX_STORES:
                _stores.popitem(last=False)
        else:
            _stores.move_to_end(key)
        return store


def extract_citations(text: str) -> list[str]:
    return list(dict.fromkeys(CITATION_RE.findall(text)))
